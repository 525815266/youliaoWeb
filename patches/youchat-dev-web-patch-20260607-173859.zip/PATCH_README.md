﻿# YouChat Dev Web Portable Patch

Generated: 2026-06-07T09:38:59.4774341Z

## Import

`powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\import-devkit-patch.ps1 -PatchZip <zip> -TargetPath <target>
`

The importer copies the payload folder into the target path and backs up overwritten files under .youchat-patch-backups.

## After Client Updates

Run:

`powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\audit-client-update.ps1 -ClientRoot "C:\Program Files\youchat-desktop"
`

Then review eports/client-update-audit-*.md before exporting a new patch.
