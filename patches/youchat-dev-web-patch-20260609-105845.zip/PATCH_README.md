﻿# YouChat Dev Web Portable Patch

Generated: 2026-06-09T02:58:45.3064819Z

## Import

`powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\import-devkit-patch.ps1 -PatchZip <zip> -TargetPath <target>
`

The importer copies the payload folder into the target path and backs up overwritten files under .youchat-patch-backups.

## After Client Updates

Run:

`powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\audit-client-update.ps1 -ClientRoot "C:\Program Files\youchat-desktop"
`

Then review eports/client-update-audit-*.md before exporting a new patch.
