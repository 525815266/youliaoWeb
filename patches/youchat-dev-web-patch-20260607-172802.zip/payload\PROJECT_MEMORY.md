# 悠聊 Web 二开项目记忆

> 本文档给项目负责人和开发者阅读。后续每次做了有意义的功能、接口、UI、状态逻辑、部署或验证改动，都必须同步更新本文档和 `AI_HANDOFF.md`，避免后续接手时丢失关键上下文。

## 目录

1. [项目目标](#1-项目目标)
2. [当前架构](#2-当前架构)
3. [启动与验证](#3-启动与验证)
4. [真实接口原则](#4-真实接口原则)
5. [会话列表与账号口径](#5-会话列表与账号口径)
6. [聊天区与历史消息](#6-聊天区与历史消息)
7. [右侧工具栏](#7-右侧工具栏)
8. [快捷回复、Skill 与 AI](#8-快捷回复skill-与-ai)
9. [图片与输入框](#9-图片与输入框)
10. [好友请求与会话操作](#10-好友请求与会话操作)
11. [UI 设计规则](#11-ui-设计规则)
12. [本次关键修复](#12-本次关键修复)
13. [已知风险与后续方向](#13-已知风险与后续方向)
14. [文档维护规则](#14-文档维护规则)
15. [2026-06-07 AI 推荐条二次修复](#15-2026-06-07-ai-推荐条二次修复)
16. [2026-06-07 好友请求全部来源修复](#16-2026-06-07-好友请求全部来源修复)
17. [2026-06-07 历史会话悬停接入](#17-2026-06-07-历史会话悬停接入)
18. [2026-06-07 原生图标与会话滚动修复](#18-2026-06-07-原生图标与会话滚动修复)
19. [2026-06-07 可迁移补丁体系](#19-2026-06-07-可迁移补丁体系)

## 1. 项目目标

本项目的目标是把悠聊 Windows Electron 客户端逐步二次开发成可运行、可扩展的 Web 客服工作台。

当前阶段不是做演示假页面，而是尽可能复刻原客户端的真实客服能力：登录、会话列表、聊天记录、右侧用户信息、订单、流水明细、快捷回复、好友请求、会话关闭/接入、图片发送和 AI 辅助回复。

长期方向是：

- 服务端与数据库尽量 Docker 化，减少必须挂 Windows 机器的依赖。
- Web 前端承载客服操作界面，支持多人协同、远程办公和二次开发。
- 接入 AI 大模型、快捷回复和 skill 知识库，提高客服回复效率。
- 所有可查询的信息优先走悠聊真实接口或真实数据库，不用假用户、假编号、假订单。

## 2. 当前架构

主项目目录：

`C:\tmp\youchat-dev-web`

原 Electron 客户端参考目录：

`C:\Program Files\youchat-desktop`

核心文件：

- `public/index.html`：静态页面骨架，包含登录页、工作台、聊天区、右侧工具栏、AI 设置弹层。
- `public/app.js`：主前端逻辑，包含状态、接口封装、渲染、会话、消息、工具栏、AI、skill、图片发送。
- `public/styles.css`：全部 UI 样式，蓝白紧凑客服工作台风格。
- `server.js`：本地 Node 服务，提供静态资源、悠聊 API 代理、AI 中转、OSS 上传代理、本地 skill 读写接口。
- `data/reply-skills.json`：本地 skill 知识库和自动学习结果持久化文件。
- `logs/api-capture.ndjson`：所有 `/api/*` 代理请求和响应的抓取日志。
- `capture-client-proxy.js`、`start-client-capture-proxy.ps1`、`watch-api-capture.ps1`：辅助抓包与查看接口日志。

当前开发服务：

`http://localhost:5177`

## 3. 启动与验证

启动：

```powershell
cd C:\tmp\youchat-dev-web
npm run dev
```

语法检查：

```powershell
npm run check
```

接口健康检查：

```powershell
Invoke-WebRequest http://localhost:5177/health
```

静态资源检查：

```powershell
Invoke-WebRequest http://localhost:5177/app.js
Invoke-WebRequest http://localhost:5177/styles.css
```

当前已验证过：

- `npm run check` 通过。
- `/health`、`/app.js`、`/styles.css` 之前已通过访问验证。
- Playwright 当前未安装，不能依赖它做截图验证。

## 4. 真实接口原则

用户明确要求：不要假数据。

前端所有数据都应来自真实悠聊接口、本地真实抓包或本地真实持久化文件。除非接口失败时为了避免页面完全空白，可以保留极少量“预览兜底”，但不能把兜底当真实数据展示给业务使用。

本地代理规则：

- 前端请求 `api("/xxx", data)`。
- 实际走 `server.js` 的 `/api/xxx?__target=真实APIBase`。
- `server.js` 会把请求和响应写入 `logs/api-capture.ndjson`。
- AI 请求走 `/ai/chat/completions`，再由 `server.js` 转发到 OpenAI 兼容中转站。

关键真实接口：

- `/System/GetOptions`
- `/System/LogIn`
- `/Senstive/GetAccountList`
- `/Contact/GetContactList`
- `/ChatContent/GetList`
- `/ChatContent/GetChatContentList`
- `/ChatContent/ConsumeMessage`
- `/ChatContent/SendMsg`
- `/Faq/GetPageList`
- `/Faq/GetTypeList`
- `/Order/GetPageList`
- `/Order/GetAccDetailPageList`
- `/Contact/GetNewFirend`
- `/Contact/NewFirendAccept`
- `/Contact/NewFirendIgnor`
- `/Conversation/ShutDown`
- `/Conversation/ShutDownAll`
- `/Conversation/AccessInAll`
- `/Conversation/TransferToAI`

## 5. 会话列表与账号口径

会话列表分三个页签：

- 当前
- 留言
- 历史

重要口径：

当前会话列表不能用全局商户号、登录名或旧 localStorage 里的错误 accountId。当前列表必须先通过 `GET /Senstive/GetAccountList` 找到当前客服账号，并使用该账号对象的 `id` 作为 `/Contact/GetContactList` 的 `accountId`。

已知真实返回示例：

- 登录账号：`Boom666`
- 客服昵称：`客服-王`
- 当前会话列表应使用：`id: 2`
- 返回里的长 `accountId: 1556504756803862529` 不是当前会话列表的筛选 ID。

如果当前页签显示类似 `8018` 这种全局数量，通常说明 accountId 口径错了。已在 `public/app.js` 中增加 `accountIdResolved`，强制优先用 `/Senstive/GetAccountList` 校验后的 `id`，并避免旧缓存污染当前列表。

会话排序：

- 普通会话按最后回复/最后消息时间排序。
- 待办/置顶会话需要特殊显示，并允许排在上面。
- 清空列表后，Web 端会本地归档到历史缓存，并临时过滤刚清空的联系人，避免自动刷新马上把列表弹回来。

## 6. 聊天区与历史消息

中间聊天区：

- 用户名和消息内容分行显示。
- 最新消息应显示在底部，符合常见聊天习惯。
- 顶部有“加载更多”入口，用于加载更早历史。
- 自动刷新时，如果客服不在底部，不应强行把滚动条跳回底部。
- 点击带未读红点的会话时，需要清除小数字，并同步 `/ChatContent/ConsumeMessage`。

右侧工具栏的聊天记录：

- 属于同一联系人的历史记录浏览。
- 最新消息应在底部。
- 向上滚动应动态加载更早历史。
- 不应轻易显示“没有更多”，除非接口分页确实无更多数据。

消息分类：

- 客户消息：需要 AI/skill 判断是否要回复。
- 客服消息：用于学习人工回复。
- 系统提示：只给客服看，不是真正发给客户的消息，不能当作客户消息自动回复。
- 提现成功、到账提醒等通知类消息：通常不需要回复，应归入 no-reply skill。

## 7. 右侧工具栏

右侧工具栏当前包含：

- 用户
- 快捷回复
- skill 回复
- 订单
- 明细
- 聊天记录

用户要求：

- 切换左侧联系人时，右侧保持当前工具栏页签。例如已经在“聊天记录”，点击下一个人后仍停留在“聊天记录”。
- 右侧蓝色真实字段可点击复制。
- 用户信息不能截断关键信息，备注要显示出来。
- 订单按平台展示，蓝色订单号/关键编号可点击复制。
- 明细实际是账户流水明细，不是普通用户资料。

相关函数：

- `renderToolContent`
- `setToolTab`
- `loadToolDataForActiveTab`
- `renderQuickReplyPanel`
- `renderSkillReplyPanel`
- `renderOrderPanel`
- `renderAccountDetails`
- `renderHistoryPanel`

## 8. 快捷回复、Skill 与 AI

快捷回复：

- 应从 `/Faq/GetPageList`、`/Faq/GetTypeList` 拉真实数据库数据。
- UI 应接近原客户端，有“发送”和“编辑”按钮。
- 快捷回复内容会作为 AI 推荐上下文的一部分。

Skill 回复：

- 本地文件：`data/reply-skills.json`
- 本地接口：
  - `GET /local/reply-skills`
  - `POST /local/reply-skills`
  - `POST /local/reply-skills/learn`
- skill 可包含关键词、样例、优先级、多步骤回复、图片、是否允许自动回复、是否 no-reply。
- 典型场景：订单查不到、红包导致无返利、返回直播间下单、绑定支付宝失败、提现成功无需回复。

AI 设置：

- 默认 API 端点：`https://sub2.sn55.cn/`
- 默认模型：`gpt-5.4-mini`
- API 密钥已写在前端默认配置和本地设置中。
- 设置通过 localStorage 持久化。
- 右上角齿轮可开关 AI 推荐、skill 自动回复、自动学习。

AI 推荐逻辑：

- AI 推荐现在默认自动开启，只要设置中没有关闭、API key 存在、有真实客户上下文，就会在切换会话或拉到新消息后自动生成候选。
- 自动推荐会先匹配 skill；未命中时才请求 AI 中转。
- 自动推荐用最新客户消息生成 key 去重，避免 10 秒自动刷新反复请求。
- 发送框上方展示 1 到 3 条横条候选，每条有“采用”和“发送”。
- 如果客服不采用 AI 推荐，而是自己发送文字或图片，会触发自动学习。
- 同类人工回复命中超过一定次数后，可提升 skill 优先级并允许自动回复。

## 9. 图片与输入框

输入区支持：

- 粘贴图片。
- 拖拽图片。
- 点击图片按钮选择图片。
- 图片和文字可同时在输入框区域准备，但发送时仍按接口能力分开发送。
- AI 只优化文字，不优化图片。
- 采用文字优化候选时，应保留原图。

图片发送相关函数：

- `handleReplyPaste`
- `handleReplyDrop`
- `sendText`
- `sendImageFile`
- `sendChatContent`
- `uploadImage`
- `uploadImageViaLocalProxy`

## 10. 好友请求与会话操作

好友请求：

- 左上工具按钮进入好友请求弹层。
- 使用 `/Contact/GetNewFirend` 拉取。
- 支持状态、来源、机器人、关键词筛选。
- 通过和忽略走 `/Contact/NewFirendAccept`、`/Contact/NewFirendIgnor`。

会话列表操作：

- 右键菜单需要区分当前、留言、待办等状态。
- 留言列表存在“全部接入”等操作。
- 当前列表支持关闭、解除、解除全部、清空列表、全部已读等。
- 鼠标悬停会话显示快捷按钮，例如接入、关闭。
- 选中会话后键盘上下键可切换会话。
- 从左侧点击切换会话后，主聊天区默认必须落在最新消息底部。
- 只有消息 DOM 里存在真实红点锚点 `[data-red-point="true"]` 时，才允许跳到红点消息；不能把第一条普通客户消息当未读锚点。

清空列表：

- 原客户端清空后当前列表会真的空掉，并进入历史。
- Web 端已实现本地归档和刷新过滤，避免接口刷新后马上重新出现。

## 11. UI 设计规则

这是高密度客服工具，不是营销页。

设计原则：

- 保留悠聊蓝白识别。
- 紧凑、可扫读、低干扰。
- 不做大卡片看板，不做深色 AI 工具风，不用紫色渐变。
- 工具按钮要像客户端工作台，不能像低保真 demo。
- 输入框和发送按钮必须始终可见，AI 推荐不能把输入框挤走。
- 右侧栏与中间聊天区要稳定，不要自动刷新时闪跳。
- 文字不要溢出、错位或把用户名和消息挤在一行。

## 12. 本次关键修复

本次任务新增了两类工作：项目记忆文档，以及 AI 推荐/当前数量/UI 的修复。

文档：

- 新增 `PROJECT_MEMORY.md`：给人读的完整项目记忆。
- 新增 `AI_HANDOFF.md`：给后续 AI 快速接手的路径和函数索引。

AI 推荐：

- AI 推荐不再必须手动点击才生成。
- 在切换会话和加载/刷新消息后，会自动尝试生成推荐。
- 自动推荐先走 skill，没命中才走 AI 中转。
- 同一联系人同一条最新客户消息只生成一次，避免自动刷新反复打接口。
- 手动点击“AI 推荐”仍保留，且会显示错误提示；自动推荐静默失败，只写日志。

AI 推荐 UI：

- 推荐区域从“方块卡片”改成横条清单。
- 左侧固定显示“AI 推荐 / 文字优化 / skill 回复”和关闭按钮。
- 右侧动态显示 1 到 3 条候选：
  - `1. 文案  采用  发送`
  - `2. 文案  采用  发送`
  - `3. 文案  采用  发送`
- 全局“采用/发送”按钮隐藏，仅每条候选自己带操作。
- 推荐区高度控制在较小范围，避免挤掉输入框。

当前列表数量：

- 增加 `accountIdResolved`。
- 当前会话列表优先通过 `/Senstive/GetAccountList` 获取客服账号对象的 `id`。
- 避免旧 localStorage 或登录返回里的长 `accountId` 把当前会话数量带成全局数量。

## 13. 已知风险与后续方向

已知风险：

- 某些 PowerShell 输出会把中文显示成乱码，但源文件本身是 UTF-8；修改时不要按终端乱码内容盲改。
- Playwright 未安装，暂时无法自动截图验证 UI。
- 部分接口参数仍来自 HAR 和 Electron 参考，后续应继续抓包比对。
- 快捷回复是否完整拉到，还需要继续对照原客户端真实接口和返回结构。
- 右侧聊天记录的历史分页需要持续观察接口是否返回 total、current、size 或游标。

后续建议：

- 继续深挖 Electron 源码和 `YouChatService.xml`。
- 对每个原客户端按钮做接口映射表。
- 把抓包日志里的成功请求整理成稳定 API 文档。
- 补一个浏览器自动化验证工具，至少能检查输入框、推荐条、滚动位置和右侧工具栏。

## 14. 文档维护规则

以后每次修改项目，都按以下规则更新：

1. 改功能：更新对应章节，写清行为变化。
2. 改接口：更新接口名、参数、返回口径、失败兜底。
3. 改 UI：更新 UI 规则和具体模块。
4. 改 AI/skill：更新触发规则、学习规则、文件路径。
5. 修 bug：写入“本次关键修复”或新增日期小节。
6. 新增关键文件：同步写到 `AI_HANDOFF.md`。
7. 验证过什么：写清命令和结果。

这两份文档是项目记忆，不是一次性说明。后续不要只在聊天里解释，必须落到 Markdown。

## 15. 2026-06-07 AI 推荐条二次修复

用户反馈 AI 推荐区存在两个明显问题：

- 关闭按钮被放在左侧标题下面，看起来像一个小横线，位置不直观。
- 候选经常只有一条，并且外观像临时拼出来的细输入框，不够像客服工具里的推荐清单。

本次修复：

- 关闭按钮改为推荐条右上角的 18px 圆形小按钮，悬停时显示蓝色焦点。
- 左侧区域只保留“AI 推荐 / 文字优化 / skill 回复”小标签，不再竖向堆按钮。
- 候选区改为真正的清单行，每条行内包含编号、两行内文案、采用、发送。
- 修复 `1. 1.` 双编号问题，单文本候选不再由 `formatSuggestionText` 再编号。
- AI prompt 从“一条回复”改为“1 到 3 条候选回复”，优先要求 JSON 数组，失败时允许 `1. 2. 3.` 分行。
- 如果模型只返回一条，前端通过 `buildLocalSuggestionVariants` 补足简短/安抚候选，避免界面孤零零只显示一条。

涉及文件：

- `public/app.js`
- `public/styles.css`
- `PROJECT_MEMORY.md`
- `AI_HANDOFF.md`

## 19. 2026-06-07 可迁移补丁体系

用户提出：除了持续写好 Markdown 记忆，还希望后续客户端更新、接口变化时能够继续跟随更新；并且最好能做成一个 patch，方便导入到任意位置的客户端源码。

当前实现不是 git diff，而是 zip overlay 补丁体系。原因是后续目标目录可能不是 git 仓库，也可能是任意机器、任意目录或一份新客户端源码。zip 补丁更适合直接导入。

新增文件：

- `PATCH_GUIDE.md`：补丁导出、导入、客户端更新审计的完整使用说明。
- `tools/export-devkit-patch.ps1`：导出当前二开工程为 zip 补丁。
- `tools/import-devkit-patch.ps1`：导入 zip 补丁到目标目录，覆盖前自动备份。
- `tools/audit-client-update.ps1`：客户端升级后的资源与接口审计工具。

`package.json` 新增命令：

- `npm run patch:export`
- `npm run client:audit`

导出补丁：

```powershell
cd C:\tmp\youchat-dev-web
npm run patch:export
```

默认输出：

```text
C:\tmp\youchat-dev-web\patches\youchat-dev-web-patch-<timestamp>.zip
```

补丁内容：

- `payload/`：项目文件。
- `youchat-devkit-manifest.json`：文件哈希、生成时间、原客户端关键资源指纹。
- `PATCH_README.md`：补丁包内说明。

导入补丁：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File C:\tmp\youchat-dev-web\tools\import-devkit-patch.ps1 `
  -PatchZip C:\tmp\youchat-dev-web\patches\youchat-dev-web-patch-xxxx.zip `
  -TargetPath D:\target\youchat-dev-web
```

导入安全：

- 如果目标文件已存在且内容不同，会先备份到 `<TargetPath>\.youchat-patch-backups\<timestamp>`。
- 导入报告在备份目录的 `import-report.json`。

客户端更新审计：

```powershell
cd C:\tmp\youchat-dev-web
npm run client:audit
```

审计输出：

- `reports/client-update-audit-<timestamp>.json`
- `reports/client-update-audit-<timestamp>.md`

审计重点：

- `fontIcon/iconfont.css` 和 `iconfont.woff2` 是否变化。
- Braft 图标 CSS 是否变化。
- `emojiSource*.png` 是否变化。
- `bin/YouChatService.xml` 是否变化。
- 扫描到的接口候选是否变化。

维护要求：

- 客户端更新后先跑 `npm run client:audit`，再判断是否需要更新 glyph 映射、红包雪碧图位置或接口参数。
- 修复确认后再跑 `npm run patch:export` 生成新版补丁。
- 每次补丁体系变化要同步更新 `PATCH_GUIDE.md`、`PROJECT_MEMORY.md`、`AI_HANDOFF.md`。

## 16. 2026-06-07 好友请求全部来源修复

用户反馈好友请求弹层里“全部来源”为空，但单独选择“微信卡片”“扫描二维码”等来源可以显示数据。抓包和本地代理验证确认：

- 不传 `scene/scenes` 的请求返回 `total: 0`。
- `scene=17, scenes=17`（微信卡片）返回 `total: 1453`。
- `scene=3, scenes=3`（搜索微信号）返回 `total: 7`。
- `scene=30, scenes=30`（扫描二维码）返回 `total: 3`。

因此“全部来源”不能直接调用空来源接口。当前实现已改为：

- `loadFriendRequestsBySource(source, page, size)`：单来源真实请求。
- `loadAllFriendRequestSources(page, size)`：并发请求全部来源 `1/3/17/14/30`，合并、去重、按请求时间排序，再做前端分页。
- `mergeFriendRequests(records)`：按真实 id 或机器人+wxid+来源去重。
- `friendSourceCounts`：记录每个来源的真实 total，来源标签显示数量徽标。
- 左上角好友请求角标取聚合总数，超过 99 显示 `99+`。

UI 同步修复：

- 左上角好友请求按钮不再用文字“人”或乱码符号。
- 改为悠聊原客户端 `fontIcon/iconfont.css` 里的 `\e60e` 用户图标。
- 红色角标 0 时隐藏，有数据时显示，超过 99 显示 `99+`。

涉及文件：

- `public/app.js`
- `public/index.html`
- `public/styles.css`
- `PROJECT_MEMORY.md`
- `AI_HANDOFF.md`

## 17. 2026-06-07 历史会话悬停接入

用户要求历史会话列表中，鼠标悬停某个会话时显示“接入”按钮。点击后应调用接入接口，并跳转到“当前”列表。

当前实现：

- `getContactHoverActions(contact, contactId)` 根据左侧页签决定 hover 按钮：
  - 留言：接入 + 关闭。
  - 历史：只显示接入。
  - 当前：只显示关闭。
- 历史接入按钮使用 `data-contact-action="access-history"`。
- `handleContactAction` 识别 `access-history` 后调用 `accessHistoryContact(contact)`。
- `accessHistoryContact` 调用真实接口 `/Conversation/AccessIn`，参数为 `contactId` 和 `accountId`。
- 接入成功后：
  - 从本地历史缓存移除该联系人。
  - `state.listTab` 切到 `current`。
  - 刷新当前会话列表。
  - 如果后端已同步到当前列表，则选中新会话。
  - 如果后端同步慢，则先把该联系人临时插入当前列表，保证用户能看到动作反馈。

涉及文件：

- `public/app.js`
- `public/styles.css`
- `PROJECT_MEMORY.md`
- `AI_HANDOFF.md`

## 18. 2026-06-07 原生图标与会话滚动修复

用户反馈 Web 端很多图标像临时找的，输入框上方快捷按钮大小不一，不像原 Windows Electron 客户端；同时从左侧会话列表点击某个会话后，主聊天区没有滚到最下面。

本次处理原则：

- 优先使用原客户端可追溯资源。
- 原包没有的资源不硬套错误素材。例如 `wwwroot/pro_icon.svg` 和 `wwwroot/icons/icon-128x128.png` 实际是 Ant Design Pro 默认 “Pro” 图标，不是悠聊品牌图，因此没有替换成它。
- 不再引入外部图标库或随机符号。

原生图标来源：

- 悠聊 iconfont：`C:\Program Files\youchat-desktop\wwwroot\fontIcon\iconfont.css`。
- Braft 编辑器 iconfont：从原客户端 chatHistory chunk CSS 里的 base64 `braft-icons` 字体提取，由本地服务暴露为 `/native-icons/braft-icons.woff`。
- 红包图标：原客户端表情雪碧图 `C:\Program Files\youchat-desktop\wwwroot\static\emojiSource.cdbf96da.png`，由本地服务暴露为 `/static/emojiSource.cdbf96da.png`，使用原 `e2_09` 红包格子。

当前图标映射：

- 表情：`bfi-emoji`
- 发送指令：`bfi-code`
- 选择图片：`bfi-media`
- 发送红包：`emojiSource.cdbf96da.png` 红包雪碧格
- 截图：`bfi-camera`
- 保存到 skill 回复：`bfi-pushpin`
- 转入 AI：悠聊 iconfont `\e61a`
- AI 设置：悠聊 iconfont `\e605`
- 好友请求：悠聊 iconfont `\e60e`
- 刷新：`bfi-replay`
- 关闭：`bfi-close`
- 复制：`bfi-copy`
- 搜索：`bfi-search`
- 登录账号下拉：`bfi-drop-down`

服务端新增/确认：

- `server.js` 增加 `CLIENT_WWWROOT`，默认指向 `C:\Program Files\youchat-desktop\wwwroot`。
- `server.js` 增加字体 MIME：`.woff`、`.woff2`、`.ttf`。
- `sendClientBraftIcons()` 从原客户端 CSS 提取 Braft 字体。
- `sendClientStaticAsset()` 只允许读取原客户端 `wwwroot` 内的静态资源。
- 路由 `/native-icons/braft-icons.woff` 返回 `font/woff`。
- 路由 `/static/emojiSource.cdbf96da.png` 返回原表情雪碧图。

UI 修复：

- 输入框上方 7 个快捷图标统一为 30px 按钮。
- 字体图标统一 17px，红包雪碧图为 18px。
- 快捷回复、skill、订单搜索按钮统一使用原生 `bfi-search`。
- 复制按钮统一使用原生 `bfi-copy`。
- 会话 hover 的接入、关闭按钮统一为原生 `client-icon-enter`、`bfi-close`。
- 好友请求角标继续 0 隐藏、超过 99 显示 `99+`。
- 清理了重复的 `.quick-search .icon-search-button` 样式，避免后续覆盖导致按钮大小不一致。

会话滚动 bug 修复：

- 问题根因：`scrollToFirstUnreadMessage()` 之前查询 `[data-red-point='true'], .message.incoming`，如果会话有未读数字但当前消息没有真实红点字段，就会退而跳到第一条普通客户消息，导致点击会话后看起来停在上方。
- 修复后：`scrollToFirstUnreadMessage()` 只查 `[data-red-point='true']`。
- 新增 `hasUnreadMessageAnchor()` 判断是否有真实红点消息锚点。
- 新增 `scheduleMessageListBottom()`，在切换会话完成加载后兜底滚动到底部。
- 普通点击会话、重复点击当前会话、未读但无真实红点锚点的会话，都会回到最新消息底部。

验证结果：

- `npm run check` 通过。
- `GET http://localhost:5177/health` 返回 200。
- `GET http://localhost:5177/native-icons/braft-icons.woff` 返回 200，长度 11348，类型 `font/woff`。
- `GET http://localhost:5177/static/emojiSource.cdbf96da.png` 返回 200，长度 616827，类型 `image/png`。
- `GET http://localhost:5177/fontIcon/iconfont.woff2` 返回 200。
- Chrome CDP 验证输入框工具栏：
  - 7 个工具按钮均为 30x30。
  - 字体图标为 17x17。
  - 红包雪碧图为 18x18。
  - 工具栏高度 34px。
  - 工具栏到底部输入框间距 6px。
- Chrome CDP 验证会话滚动：模拟有未读数字但没有真实红点锚点的会话，切换后 `bottomGap = 0`，即主聊天区在最底部。
- 截图文件：
  - `C:\tmp\youchat-dev-web\login-native-icon-check.png`
  - `C:\tmp\youchat-dev-web\workbench-native-icon-check.png`

涉及文件：

- `server.js`
- `public/index.html`
- `public/styles.css`
- `public/app.js`
- `PROJECT_MEMORY.md`
- `AI_HANDOFF.md`
